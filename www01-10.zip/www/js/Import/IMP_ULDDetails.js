﻿//document.addEventListener("deviceready", GetCommodityList, false);

//var global_variable;
//var global_variable2;

$(function () {    
   
    $('#txtFltNo').val(amplify.store("flightNo"));
    $('#txtFltDate').val(amplify.store("flightDate"));
});

